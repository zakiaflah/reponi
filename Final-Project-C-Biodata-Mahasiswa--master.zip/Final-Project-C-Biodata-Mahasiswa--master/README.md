===== BIODATA MAHASISWA =====

-> kami memilih membuat penyimpanan biodata mahasiswa ini karena pendataan itu sangat penting dalam sebuah organisasi,oleh karena itu diharapkan dengan aplikasi ini UKM atau organisasi dapat membuat event sesuai dengan data yang ada.Aplikasi ini terdapat 3 form yaitu form Signup, form Login, dan Form Identitas.Untuk penyimpanan datanya menggunakan database mysql di phpmyadmin agar data bisa tersimpan sekaligus bisa update data jika ada kesalahan dalam inputan di form Identitas.
Cara run :
1. Agar bisa berjalan pertama import database yang sudah di sediakan
2. Pastikan terdapat mysqlclient (untuk visual studio 2010 tambahkan secara manual Mysql.Data.dll di folder -> \..\..\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.0\MySql.Data.dll ) lalu pada common properties di visual studio pilih Add New Reference.. -> .NET -> Cari MySql.Data
3. Jalankan Program di -> \..\Final Project C++\finalproject\Signup\Debug\Signup.exe

-> Anggota Kelompok
   1. Dwiky Alfian Tama		18.83.0297
   2. Muhammad Zaki Aflahdiyag	18.83.0333
   3. Roni Septian		18.83.0330
   4. Denie Wahyu Pratama	18.83.0293

-> Tema yang dipilih => Aplikasi tepat guna yaitu aplikasi biodata mahasiswa

-> Tools yang digunakan
   1. Visual Studio Ultimate 2010
   2. XAMPP (phpmyadmin)
   3. Mysqlclient

-> Algoritma yg digunakan : - CRUD (Create,Read,Update,Delete) mysql

-> Link source
   1. https://www.youtube.com/watch?v=6-j6mkROFCM&t=716s
   2. https://www.youtube.com/watch?v=dmYaTfrV8lE
